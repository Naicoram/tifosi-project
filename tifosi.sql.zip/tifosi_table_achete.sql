
-- --------------------------------------------------------

--
-- Structure de la table `achete`
--

DROP TABLE IF EXISTS `achete`;
CREATE TABLE IF NOT EXISTS `achete` (
  `id_client` int DEFAULT NULL,
  `id_focaccia` int DEFAULT NULL,
  `jour` date NOT NULL,
  KEY `focaccia` (`id_focaccia`),
  KEY `Client` (`id_client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
